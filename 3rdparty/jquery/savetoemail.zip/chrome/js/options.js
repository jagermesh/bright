$(document).ready(function() {

  $('#settingsForm input.settings-field').on('keyup', function() {
    $('#settingsSaved').hide();
    $('#settingsSaveError').hide();
  });
  $('#settingsForm input.settings-field').on('change', function() {
    $('#settingsSaved').hide();
    $('#settingsSaveError').hide();
  });

  chrome.storage.sync.get(function(options) {
    for(var name in options) {
      var control = $('#settingsForm input[name=' + name + ']');
      if (control.length > 0) {
        if ($(control).attr('type') == 'radio') {
          control.removeProp('checked');
          control = $('#settingsForm input[name="' + name + '"][value="' + options[name] + '"]');
          control.prop('checked', 'checked');
        } else {
          control.val(options[name]);
        }
      }
    }
    $('#settingsForm').show();
  });

  // $('#settingsForm').modal('show');

  $('#saveSettings').on('click', function() {
    var settings = {};
    var required = [];
    $('#settingsForm input.settings-field').each(function() {
      if ($(this).attr('type') == 'radio') {
        if ($(this).is(':checked')) {
          settings[$(this).attr('name')] = $(this).val();
        }
      } else {
        settings[$(this).attr('name')] = $(this).val();
        if ($(this).hasClass('required') && br.isEmpty($(this).val())) {
          required.push({ control: $(this), title: $(this).attr('title') });
        }
      }
    });
    if (required.length > 0) {
      var s = '<p>Please enter<ul>';
      $('#settingsSaveError').append($());
      $.each(required, function() {
        s += '<li>' + this.title + '</li>';
      });
      s += '</ul></p>';
      required[0].control[0].focus();
      $('#settingsSaveError').html(s).fadeIn();
    } else {
      chrome.storage.sync.set(settings, function() {
        $('#settingsSaved').fadeIn();
      });
    }
  });

});
