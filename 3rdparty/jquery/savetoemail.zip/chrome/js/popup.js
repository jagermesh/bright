$(document).ready(function() {

  $('body').removeClass('error');
  $('#status').text('');

  // var docscampDocumentsDataSource = br.dataSource('https://ny.edoctrina.org/v2/api/pageToMail/');
  var docscampDocumentsDataSource = br.dataSource('http://savetoemail.com/api/1.0/');
  // var docscampDocumentsDataSource = br.dataSource('http://local.jagermesh.com/reviewlater/api/1.0/');

  chrome.runtime.onMessage.addListener(function(request, sender) {
    if (request.action == 'getPageSource') {
      chrome.tabs.getSelected(function(tab) {
        chrome.storage.sync.get(function(options) {
          if (br.isEmpty(options.targetEmail) || br.isEmpty(options.contentDisposition)) {
            chrome.runtime.openOptionsPage();
          } else {
            $('#pageSource').text('');
            $('#status').text('Sending page to ' + options.targetEmail);
            docscampDocumentsDataSource.invoke('send', { url: tab.url
                                                       // , senderEmail: options.senderEmail
                                                       , targetEmail: options.targetEmail
                                                       , contentDisposition: options.contentDisposition
                                                       , html: request.source
                                                       }, function(result, response) {
              if (result) {
                $('#status').text('Sent');
                window.setTimeout(function() {
                  window.close();
                }, 3000);
              } else {
                $('body').addClass('error');
                $('#status').html('Error: ' + response);
              }
            });
          }
        });
      });
    }
  });

});

chrome.tabs.executeScript(null, { file: 'js/get-page-source.js' } );
